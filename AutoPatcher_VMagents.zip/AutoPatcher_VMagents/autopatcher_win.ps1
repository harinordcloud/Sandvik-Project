Invoke-WebRequest -Uri https://auto-patcher-core-prod-integratorcliuploadbucket-x9ofi9eidydb.s3.amazonaws.com/ap-installer-windows-prod.exe -OutFile ap-installer.exe

./ap-installer <LICENSE>
