wget https://auto-patcher-core-prod-integratorcliuploadbucket-x9ofi9eidydb.s3.amazonaws.com/ap-installer-linux-prod -O ap-installer && chmod +x ap-installer

sudo ./ap-installer <LICENSE>
